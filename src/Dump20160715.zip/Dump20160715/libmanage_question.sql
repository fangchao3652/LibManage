-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: libmanage
-- ------------------------------------------------------
-- Server version	5.7.13-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `question` (
  `id` int(16) NOT NULL,
  `eno` int(16) NOT NULL,
  `quesNum` int(16) NOT NULL,
  `topic` varchar(255) NOT NULL,
  `options` text,
  `optionA` varchar(255) DEFAULT NULL,
  `optionB` varchar(255) DEFAULT NULL,
  `optionC` varchar(255) DEFAULT NULL,
  `optionD` varchar(255) DEFAULT NULL,
  `answer` int(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `question_ibfk_1` (`eno`),
  CONSTRAINT `question_ibfk_1` FOREIGN KEY (`eno`) REFERENCES `experiment` (`eno`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question`
--

LOCK TABLES `question` WRITE;
/*!40000 ALTER TABLE `question` DISABLE KEYS */;
INSERT INTO `question` VALUES (9,14241811,1,'测试1','[\'JavaScript库\',\'CSS库\',\'PHP框架\',\'以上都不是\']','A','B','C','D',1),(10,14241811,2,'测试2','[\'JavaScript库\',\'CSS库\',\'PHP框架\',\'以上都不是\']','A','B','C','D',2),(11,14241811,3,'测试3','[\'JavaScript库\',\'CSS库\',\'PHP框架\',\'以上都不是\']','A','B','C','D',1),(12,14241811,4,'测试4','[\'JavaScript库\',\'CSS库\',\'PHP框架\',\'以上都不是\']','A','B','C','D',4),(13,14241812,1,'测试1','[\'JavaScript库\',\'CSS库\',\'PHP框架\',\'以上都不是\']','A','B','C','D',2),(14,14241812,2,'测试2','[\'JavaScript库\',\'CSS库\',\'PHP框架\',\'以上都不是\']','A','B','C','D',4),(15,14241812,3,'测试3','','A','B','C','D',2),(16,14241812,4,'测试4','','A','B','C','D',1),(17,14241813,1,'测试1','','A','B','C','D',3),(18,14241813,2,'测试2','','A','B','C','D',3),(19,14241813,3,'测试3','','A','B','C','D',3),(20,14241813,4,'测试4','[\'JavaScript库\',\'CSS库\',\'PHP框架\',\'以上都不是\']','A','B','C','D',2);
/*!40000 ALTER TABLE `question` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-07-15 11:29:36
