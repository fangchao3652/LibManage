-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: libmanage
-- ------------------------------------------------------
-- Server version	5.7.13-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student` (
  `sno` int(20) NOT NULL,
  `name` varchar(255) CHARACTER SET gbk NOT NULL,
  `sex` char(10) CHARACTER SET gbk DEFAULT NULL,
  `level` varchar(255) CHARACTER SET gbk DEFAULT NULL,
  `profession` varchar(255) CHARACTER SET gbk DEFAULT NULL,
  `password` varchar(255) CHARACTER SET gbk DEFAULT '123456',
  `limitation` char(255) DEFAULT '学生',
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES (131405101,'a','男','13级','电信1','a','student'),(131405102,'b','男','13级','电信1','b','student'),(131405103,'李潮','男','13级','电信1','123456','student'),(131405104,'周成涛','男','13级','电信1','123456','student'),(131405105,'耿闯','男','13级','电信1','123456','student'),(131406101,'和世帅','男','13级','通信1','123456','student'),(131406102,'王钊','男','13级','通信1','123456','student'),(131406103,'张学文','男','13级','通信1','123456','student'),(131406104,'张明迪','女','13级','通信1','123456','student'),(131406105,'贺攀','男','13级','通信1','123456','student'),(141403101,'张翼','男','14级','硬件1','123456','student'),(141403102,'关欣荣','女','14级','硬件1','123456','student'),(141403103,'吴昊','男','14级','硬件1','123456','student'),(141403104,'付成鹏','男','14级','硬件1','123456','student'),(141403105,'祝金思','女','14级','硬件1','123456','student'),(141405101,'孙跃','男','14级','电信1','123456','student'),(141405102,'罗健','男','14级','电信1','123456','student'),(141405103,'卢誉','女','14级','电信1','123456','student'),(141405104,'肖坛','男','14级','电信1','123456','student'),(141405105,'郭仪芳','女','14级','电信1','123456','student'),(141405201,'李强','男','14级','电信2','123456','student'),(141405202,'刘泽阳','女','14级','电信2','123456','student'),(141405203,'曲学磊','男','14级','电信2','123456','student'),(141405204,'孙继伟','男','14级','电信2','123456','student'),(141405205,'霍那日苏','女','14级','电信2','123456','student'),(141406101,'邱少煜','男','14级','通信1','123456','student'),(141406102,'安越','女','14级','通信1','123456','student'),(141406103,'孟凡凯','男','14级','通信1','123456','student'),(141406104,'唐峰','男','14级','通信1','123456','student'),(141406105,'李达','男','14级','通信1','123456','student'),(141407101,'赵亮','男','14级','软件1','123456','student'),(141407102,'刘子豪','男','14级','软件1','123456','student'),(141407103,'张皓栋','男','14级','软件1','123456','student'),(141407104,'王灵鑫','女','14级','软件1','123456','student'),(141407105,'刘帅','男','14级','软件1','123456','student'),(141407201,'王善斌','男','14级','软件2','123456','student'),(141407202,'远继圣','男','14级','软件2','123456','student'),(141407203,'石林','男','14级','软件2','123456','student'),(141407204,'王广栋','男','14级','软件2','123456','student'),(141407205,'柳岸青','女','14级','软件2','123456','student');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-07-15 11:29:36
