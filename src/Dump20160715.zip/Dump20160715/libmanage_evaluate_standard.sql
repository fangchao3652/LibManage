-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: libmanage
-- ------------------------------------------------------
-- Server version	5.7.13-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `evaluate_standard`
--

DROP TABLE IF EXISTS `evaluate_standard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `evaluate_standard` (
  `id` int(16) NOT NULL,
  `eno` int(16) NOT NULL,
  `stanDesc` varchar(255) NOT NULL,
  `rankA` varchar(255) DEFAULT NULL,
  `rankB` varchar(255) DEFAULT NULL,
  `rankC` varchar(255) DEFAULT NULL,
  `rankD` varchar(255) DEFAULT NULL,
  `rankE` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `evaluate_standard_ibfk_1` (`eno`),
  CONSTRAINT `evaluate_standard_ibfk_1` FOREIGN KEY (`eno`) REFERENCES `experiment` (`eno`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evaluate_standard`
--

LOCK TABLES `evaluate_standard` WRITE;
/*!40000 ALTER TABLE `evaluate_standard` DISABLE KEYS */;
INSERT INTO `evaluate_standard` VALUES (9,14241811,'实验方案选择情况','A优秀','B良好','C中等','D及格','E不及格'),(10,14241811,'实验器材使用情况','A优秀','B良好','C中等','D及格','E不及格'),(11,14241811,'实验实际操作情况','A优秀','B良好','C中等','D及格','E不及格'),(12,14241811,'实验最终结果情况','A优秀','B良好','C中等','D及格','E不及格'),(13,14241812,'实验方案选择情况','A优秀','B良好','C中等','D及格','E不及格'),(14,14241812,'实验器材使用情况','A优秀','B良好','C中等','D及格','E不及格'),(15,14241812,'实验实际操作情况','A优秀','B良好','C中等','D及格','E不及格'),(16,14241812,'实验最终结果情况','A优秀','B良好','C中等','D及格','E不及格'),(17,14241813,'实验方案选择情况','A优秀','B良好','C中等','D及格','E不及格'),(18,14241813,'实验器材使用情况','A优秀','B良好','C中等','D及格','E不及格'),(19,14241813,'实验实际操作情况','A优秀','B良好','C中等','D及格','E不及格'),(20,14241813,'实验最终结果情况','A优秀','B良好','C中等','D及格','E不及格');
/*!40000 ALTER TABLE `evaluate_standard` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-07-15 11:29:36
