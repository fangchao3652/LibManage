-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: libmanage
-- ------------------------------------------------------
-- Server version	5.7.13-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `score`
--

DROP TABLE IF EXISTS `score`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `score` (
  `sno` int(16) NOT NULL,
  `eno` int(16) NOT NULL,
  `tno` int(16) DEFAULT NULL,
  `cno` int(16) DEFAULT NULL,
  `preStatus` int(1) DEFAULT '0',
  `preResult` text,
  `preReport` text,
  `preScore` float DEFAULT NULL,
  `login` int(1) DEFAULT '0',
  `evaStatus` int(1) DEFAULT '0',
  `evaResult` text,
  `evaScore` float DEFAULT '0',
  `picture` text,
  `code` text,
  `video` text,
  `audio` text,
  `report` text,
  `reportScore` float DEFAULT '0',
  `score` float DEFAULT '0',
  PRIMARY KEY (`sno`,`eno`),
  KEY `score_ibfk_2` (`eno`),
  KEY `score_ibfk_3` (`tno`),
  KEY `score_ibfk_4` (`cno`),
  CONSTRAINT `score_ibfk_1` FOREIGN KEY (`sno`) REFERENCES `student` (`sno`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `score_ibfk_2` FOREIGN KEY (`eno`) REFERENCES `experiment` (`eno`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `score_ibfk_3` FOREIGN KEY (`tno`) REFERENCES `teacher` (`tno`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `score_ibfk_4` FOREIGN KEY (`cno`) REFERENCES `class` (`cno`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `score`
--

LOCK TABLES `score` WRITE;
/*!40000 ALTER TABLE `score` DISABLE KEYS */;
INSERT INTO `score` VALUES (131405101,14241811,NULL,NULL,2,'[{\"id\":9, \"userAnswer\":1},{\"id\":10, \"userAnswer\":1},{\"id\":11, \"userAnswer\":1},{\"id\":12, \"userAnswer\":1}]','<p>d&#39;sdsasasdasdasdasdasdasdsa</p>\r\n',100,0,1,NULL,99,NULL,'<pre>\r\n<code class=\"language-java\">package edu.lnu.dao;\r\n\r\nimport edu.lnu.domain.Score;\r\nimport edu.lnu.util.TransactionManager;\r\nimport org.apache.commons.dbutils.QueryRunner;\r\nimport org.apache.commons.dbutils.handlers.BeanHandler;\r\n\r\n/**\r\n * Created by Meiling on 2016/7/11.\r\n */\r\npublic class ScoreDaoImpl implements ScoreDao {\r\n    @Override\r\n    public Score findScoreBySnoEno(int sno, int eno) {\r\n        String sql = \"select * from score where sno = ? and eno = ?\";\r\n        try {\r\n            QueryRunner runner = new QueryRunner(TransactionManager.getSource());\r\n            Score score = runner.query(sql, new BeanHandler&lt;Score&gt;(Score.class), sno, eno);\r\n            //  System.out.println(score);\r\n            return score;\r\n        } catch (Exception e) {\r\n            e.printStackTrace();\r\n            throw new RuntimeException(e);\r\n        }\r\n    }\r\n\r\n    @Override\r\n    public void addScore(Score score) {\r\n        String sql = \"insert into score(sno,eno,preResult,preStatus) values(?,?,?,1)\";\r\n        try {\r\n            QueryRunner runner = new QueryRunner(TransactionManager.getSource());\r\n            runner.update(sql, score.getSno(), score.getEno(), score.getPreResult());\r\n        } catch (Exception e) {\r\n            e.printStackTrace();\r\n            throw new RuntimeException(e);\r\n        }\r\n    }\r\n\r\n    @Override\r\n    public void updatePreReport(Score score, String preReport) {\r\n        String sql = \"update  score set preReport =?,preStatus=2 where sno=? and eno=?\";\r\n        try {\r\n            QueryRunner runner = new QueryRunner(TransactionManager.getSource());\r\n            runner.update(sql, preReport, score.getSno(), score.getEno());\r\n        } catch (Exception e) {\r\n            e.printStackTrace();\r\n            throw new RuntimeException(e);\r\n        }\r\n    }\r\n\r\n    @Override\r\n    public void updateCodeReport(Score score, String code, String report) {\r\n        String sql = \"update  score set code=?,report =? where sno=? and eno=?\";\r\n        try {\r\n            QueryRunner runner = new QueryRunner(TransactionManager.getSource());\r\n            runner.update(sql, code, report, score.getSno(), score.getEno());\r\n        } catch (Exception e) {\r\n            e.printStackTrace();\r\n            throw new RuntimeException(e);\r\n        }\r\n    }\r\n}\r\n</code></pre>\r\n\r\n<p>&nbsp;</p>\r\n',NULL,NULL,'<p><strong>过滤器===========================================</strong></p>\r\n',96,98.3333),(131405101,14241812,NULL,NULL,1,'1','<pre>',NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL),(131405103,14241811,1,1424181,1,'[{\"id\":9, \"userAnswer\":4},{\"id\":10, \"userAnswer\":3},{\"id\":11, \"userAnswer\":4},{\"id\":12, \"userAnswer\":4}]',NULL,NULL,1,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL),(131405104,14241811,3,1424181,1,'[{\"id\":9, \"userAnswer\":4},{\"id\":10, \"userAnswer\":3},{\"id\":11, \"userAnswer\":4},{\"id\":12, \"userAnswer\":4}]',NULL,75,1,1,NULL,85,'','',NULL,NULL,NULL,0,NULL);
/*!40000 ALTER TABLE `score` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-07-15 11:29:36
